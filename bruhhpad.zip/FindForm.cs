﻿using System;

namespace bruhhpad
{
    internal class FindForm
    {
        internal void ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}